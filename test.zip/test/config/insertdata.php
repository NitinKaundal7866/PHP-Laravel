<?php
include 'C:\xampp\htdocs\test\config\dbconn.php';

$sql = "INSERT INTO posts (title,category,status,date)
VALUES('Learn Web Development', 'Web Development', '1','07 Oct 2026'),
('Why Learn Programming?', 'Programming', '1','05 Oct 2026'),
('Getting Started With Coding', 'HTML & CSS', '0','03 Oct 2026')";
if (mysqli_query($conn, $sql)) {
     echo "data inserted";
}


mysqli_close($conn);
