<?php
include 'C:\xampp\htdocs\test\config\dbconn.php';
// $sql =  "CREATE DATABASE Blog";
// if (mysqli_query($conn, $sql)) {
//     echo "Database Created successfully";
// } else {
//     echo "Error: " . mysqli_error($conn);
// }

// $sql = "CREATE TABLE posts (
// id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
// title VARCHAR(30) NOT NULL,
// category VARCHAR(150) NOT NULL,
// status BOOLEAN NOT NULL DEFAULT 0,
// date VARCHAR(30) NOT NULL
// )";
// if (mysqli_query($conn, $sql)) {
//     echo "Table Created";
// } else {
//     echo "Error: " . mysqli_error($conn);
// }

// $sql = "INSERT INTO posts (title,category,status,date)
// VALUES('Learn Web Development', 'Web Development', '1','07 Oct 2026'),
// ('Why Learn Programming?', 'Programming', '1','05 Oct 2026'),
// ('Getting Started With Coding', 'HTML & CSS', '0','03 Oct 2026')";
// if (mysqli_query($conn, $sql)) {
//      echo "data inserted";
// }

$sql = "SELECT * FROM posts";
$results = mysqli_query($conn, $sql);

// published and draft posts total count
$query = "SELECT 
            SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as total_published,
            SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) as total_draft 
          FROM posts";

$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

// Variables mein store karna (agar database khali hai toh 0 dikhayega)
$published_count = $row['total_published'] ?? 0;
$draft_count = $row['total_draft'] ?? 0;


// if (mysqli_num_rows($results) > 0) {
//     while ($row = mysqli_fetch_assoc($results)) {
//         echo "id: " . $row["id"] . " - Title: " . $row["title"] . "<br>";
//     }
// } else {
//     echo "0 results";
// }


