<?php
include 'C:\xampp\htdocs\test\config\dbconn.php';
// Delete User
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id  = $_GET['id'];

    $sql = "DELETE FROM posts WHERE id = '$id'";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        header('location: ../admin/index.php');
    } else {
        echo "Post Not Found";
    }

    mysqli_close($conn);
}

