<?php include 'C:\xampp\htdocs\test\config\createdb.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <link href='css/style.css' rel="stylesheet">
</head>

<body>

    <!-- Header -->
    <?php include "includes/header.php" ?>

    <!-- Main Content -->
    <div class="container">

        <!-- Blog Posts -->
        <main>

            <?php
            if (mysqli_num_rows($results) > 0) {
                while ($row = mysqli_fetch_assoc($results)) {
            ?>
                    <article class="post">

                        <img
                            src="assets\blogimage\blog1.jfif"
                            alt="Laptop and web development">

                        <div class="post-content">
                            <h2><?php echo $row["title"] ?></h2>

                            <div class="date">
                                <?php echo $row["date"] ?>
                            </div>

                            <p>
                                Web development is an exciting field where you can
                                create websites and web applications using HTML,
                                CSS, JavaScript and other technologies.
                            </p>

                            <a href="#" class="read-more">
                                Read More
                            </a>
                        </div>

                    </article>
            <?php
                }
            } else {
                echo "0 results";
            } ?>
        </main>


        <!-- Sidebar -->
        <aside class="sidebar">

            <h3>Categories</h3>

            <ul>
                <li>
                    <a href="#">Web Development</a>
                </li>

                <li>
                    <a href="#">HTML & CSS</a>
                </li>

                <li>
                    <a href="#">JavaScript</a>
                </li>

                <li>
                    <a href="#">PHP</a>
                </li>

                <li>
                    <a href="#">Programming</a>
                </li>
            </ul>

        </aside>

    </div>

    <script>
        let data = localStorage.getItem("fruits");
let savedFruits = JSON.parse(data);

console.log(savedFruits);
    </script>
    <!-- Footer -->
    <?php include "includes/footer.php" ?>
</body>

</html>