  <aside class="sidebar">

      <h2>My Blog</h2>

      <ul>

          <li>
              <a href="..\admin\index.php" class="active">
                  📊 Dashboard
              </a>
          </li>

          <li>
              <a href="..\admin\allpost.php">
                  📝 All Posts
              </a>
          </li>

          <li>
              <a href="..\admin\addpost.php">
                  ➕ Add Post
              </a>
          </li>

      </ul>

  </aside>
  <script>
      document.addEventListener("DOMContentLoaded", function() {

          const currentUrl = window.location.pathname;
          const sidebarLinks = document.querySelectorAll(".sidebar ul li a");

          sidebarLinks.forEach(function(link) {
              const linkUrl = new URL(link.href, window.location.origin).pathname;

              // Pehle sabhi se active remove
              link.classList.remove("active");

              // Current page ke URL se match
              if (linkUrl === currentUrl) {
                  link.classList.add("active");
              }
          });

      });
  </script>