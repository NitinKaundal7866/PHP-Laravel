<?php include 'C:\xampp\htdocs\test\config\createdb.php' ?>

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Blog Admin Panel</title>

    <link href="css/style.css" rel="stylesheet">
</head>

<body>


    <!-- ================= SIDEBAR ================= -->
    <?php include "includes/sidebar.php" ?>


    <!-- ================= MAIN ================= -->

    <main class="main">


        <!-- TOP BAR -->

        <div class="topbar">

            <h1>Dashboard</h1>

            <div class="admin">
                Admin 👤
            </div>

        </div>


        <!-- ================= DASHBOARD CARDS ================= -->

        <div class="cards">

            <div class="card blue">
                <h3>Total Posts</h3>
                <p>
                    <?php
                    $total_posts = mysqli_num_rows($results);
                    echo $total_posts;
                    ?>
                </p>
            </div>

            <div class="card green">
                <h3>Published</h3>
                <p><?php echo $published_count; ?></p>
            </div>

            <div class="card orange">
                <h3>Draft</h3>
                <p><?php echo $draft_count; ?></p>
            </div>

            <!-- <div class="card red">
                <h3>Users</h3>
                <p>50</p>
            </div> -->

        </div>


        <!-- ================= POSTS ================= -->

        <section class="content">

            <div class="content-header">

                <h2>Recent Posts</h2>

                <a href="..\admin\addpost.php" class="add-btn">
                    + Add New Post
                </a>

            </div>


            <table>

                <thead>

                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>

                </thead>


                <tbody>
                    <?php
                    if (mysqli_num_rows($results) > 0) {
                        while ($row = mysqli_fetch_assoc($results)) {
                    ?>

                            <tr>

                                <td>
                                    <img
                                        class="post-image"
                                        src="/test/assets/blogimage/blog1.jfif"
                                        alt="Web Development">
                                </td>

                                <td>
                                    <?php echo $row["title"] ?>
                                </td>

                                <td>
                                    <?php echo $row["category"] ?>
                                </td>

                                <td>
                                    <?php echo $row["date"] ?>
                                </td>

                                <td>
                                    <?php
                                    if ($row["status"] == 0) {
                                        echo "Draft";
                                    } else {
                                        echo "Published";
                                    }
                                    ?>
                                </td>

                                <td>
                                    <a href="..\admin\editpost.php?id=<?php echo $row['id']; ?>" class="edit">
                                        Edit
                                    </a>
                                    <a href="..\config\action.php?id=<?php echo $row['id']; ?>"
                                        class="delete"
                                        type="button"
                                        onclick="return confirm('Confrim First to Delete');">
                                        Delete
                                    </a>

                                </td>

                            </tr>
                    <?php
                        }
                    } else {
                        echo "0 results";
                    } ?>
                </tbody>

            </table>

        </section>


    </main>

</body>

</html>