<?php include 'C:\xampp\htdocs\test\config\createdb.php' ?>

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Blog Admin Panel</title>

    <link href="css/style.css" rel="stylesheet">
</head>

<body>


    <!-- ================= SIDEBAR ================= -->
    <?php include "includes/sidebar.php" ?>

    <?php
    if (isset($_POST['input_form'])) {
        $title = $_POST['title'];
        $category = $_POST['category'];
        $date = $_POST['date'];
        $status = $_POST['status'];
        $id = $_POST['id'];

        $sql = "INSERT INTO posts (title, category, date, status)
         VALUES('$title', '$category', '$date', '$status')";

        if (mysqli_query($conn, $sql)) {
            header('location: ..\admin\index.php');
            exit();
        } else {
            echo "Error executing query: " . mysqli_error($conn);
        }
    }
    ?>

    <!-- ================= MAIN ================= -->

    <main class="main">
        <!-- ================= Edit POST ================= -->
        <section class="content">
            <div class="content-header">
                <h2>Edit Post</h2>
            </div>

            <div class="form-wrapper">
                <form class="form" action="" method="post">
                    <div class="form-group">

                        <label for="title">
                            Title *
                        </label>

                        <input required
                            type="text"
                            id="title"
                            name="title"
                            placeholder="Enter title">
                        <span style="color: red;" id="title-error"></span>
                    </div>

                    <div class="form-group">

                        <label for="category">
                            Category *
                        </label>

                        <input required
                            type="text"
                            id="category"
                            name="category"
                            placeholder="Enter category">
                        <span style="color: red;" id="category-error"></span>
                    </div>

                    <div class="form-group">

                        <label for="date">
                            Date *
                        </label>

                        <input required
                            type="text"
                            id="date"
                            name="date"
                            placeholder="Enter date">
                        <span style="color: red;" id="date-error"></span>
                    </div>

                    <div class="form-group">

                        <label for="status">
                            Status *
                        </label>

                        <input required
                            type="text"
                            id="status"
                            name="status"
                            placeholder="Enter status">
                        <span style="color: red;" id="status-error"></span>
                    </div>

                    <div class="form-actions">
                        <button name="input_form"
                            type="submit"
                            class="btn btn-primary">
                            Save Post
                        </button>
                    </div>
                </form>

            </div>
        </section>
    </main>
</body>

</html>