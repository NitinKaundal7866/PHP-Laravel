<?php include 'C:\xampp\htdocs\test\config\createdb.php' ?>

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Blog Admin Panel</title>

    <link href="css/style.css" rel="stylesheet">
</head>

<body>


    <!-- ================= SIDEBAR ================= -->
    <?php include "includes/sidebar.php" ?>


    <!-- ================= MAIN ================= -->

    <main class="main">
        <!-- TOP BAR -->

        <div class="topbar">

            <h1>All Posts</h1>
            <div class="total">
                <p>Total: <?php
                            $total_posts = mysqli_num_rows($results);
                            echo $total_posts;
                            ?></p>
            </div>
        </div>
        <!-- ================= All POSTS ================= -->

        <section class="content">
            <!-- 
            <div class="content-header">
                <h2>All Posts</h2>
            </div> -->

            <div class="posts-grid">

                <?php
                if (mysqli_num_rows($results) > 0) {
                    while ($row = mysqli_fetch_assoc($results)) {
                ?>

                        <div class="post-card">

                            <!-- Image -->
                            <div class="post-card-image">
                                <img
                                    src="/test/assets/blogimage/blog1.jfif"
                                    alt="<?php echo htmlspecialchars($row["title"]); ?>">
                            </div>

                            <!-- Card Content -->
                            <div class="post-card-body">

                                <div class="post-card-top">
                                    <span class="post-category">
                                        <?php echo htmlspecialchars($row["category"]); ?>
                                    </span>

                                    <?php if ($row["status"] == 0) { ?>
                                        <span class="status draft">Draft</span>
                                    <?php } else { ?>
                                        <span class="status published">Published</span>
                                    <?php } ?>
                                </div>

                                <h3 class="post-title">
                                    <?php echo htmlspecialchars($row["title"]); ?>
                                </h3>

                                <div class="post-card-footer">
                                    <span class="post-date">
                                        📅 <?php echo htmlspecialchars($row["date"]); ?>
                                    </span>

                                    <a href="#" class="view-post">
                                        View →
                                    </a>
                                </div>

                            </div>

                        </div>

                    <?php
                    }
                } else {
                    ?>

                    <div class="no-posts">
                        <p>No posts found.</p>
                    </div>

                <?php
                }
                ?>

            </div>

        </section>

    </main>

</body>

</html>