<footer>
    <p>
        &copy; 2026 My Blog. All Rights Reserved.
    </p>
</footer>