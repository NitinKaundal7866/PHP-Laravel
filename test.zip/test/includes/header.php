<header>
    <h1>My Blog</h1>

    <nav>
        <a href="#">Home</a>
        <a href="#">Blog</a>
        <a href="#">About</a>
        <a href="#">Contact</a>
    </nav>
</header>